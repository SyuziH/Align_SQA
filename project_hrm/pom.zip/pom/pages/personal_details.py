import pytest
from selenium.webdriver.common.by import By
from project_hrm.pom.base.base_page import BasePage
from selenium.webdriver import Keys


class PersonalDetails(BasePage):
    def __init__(self, driver):
        super().__init__(driver)

    NAME = (By.CSS_SELECTOR, "input[name='firstName']")
    MIDDLE_NAME = (By.CSS_SELECTOR, "input[name='middleName']")
    LAST_NAME = (By.CSS_SELECTOR, "input[name = 'lastName']")
    MY_NAME = 'Clark'

    def clear_input(self, clear_field):
        element = self.get_wait().wait_for_element(clear_field)
        self.element_send_keys(element, Keys.CONTROL + 'a')
        self.element_send_keys(element, Keys.BACK_SPACE)

    def fill_name(self, filled_name, fill_field):
        element = self.get_wait().wait_for_element_to_be_clickable(filled_name)
        self.element_send_keys(element, fill_field)
