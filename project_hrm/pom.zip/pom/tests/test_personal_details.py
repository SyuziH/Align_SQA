import pytest
from project_hrm.pom.base.selenium_driver import SeleniumDriver
from project_hrm.pom.pages.navigation_panel import NavigationPanel
from project_hrm.pom.pages.personal_details import PersonalDetails


@pytest.mark.usefixtures("log_in")
class TestPersonalDetails:

    def test_personal_details(self):
        navigation = NavigationPanel(self.driver)
        navigation.go_to('My_Info')
        personal_details_page = PersonalDetails(self.driver)
        personal_details_page.wait_for_page_load()
        personal_details_page.clear_input(PersonalDetails.NAME)
        personal_details_page.fill_name(PersonalDetails.NAME,PersonalDetails.MY_NAME)

